
let index = 0;
const images = document.querySelectorAll('.carousel-image');

function showNextImage() {
    images[index].style.opacity = 0;
    index = (index + 1) % images.length;
    images[index].style.opacity = 1;
}

function showPrevImage() {
    images[index].style.opacity = 0;
    index = (index - 1 + images.length) % images.length;
    images[index].style.opacity = 1;
}

setInterval(showNextImage, 3000);
