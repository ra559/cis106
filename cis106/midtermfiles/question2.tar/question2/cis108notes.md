112 is the number of surat al-Ikhlas in the Qur'an.
