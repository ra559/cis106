151 is the height of the Statue of Liberty from the base to the torch in feet (46 m).
